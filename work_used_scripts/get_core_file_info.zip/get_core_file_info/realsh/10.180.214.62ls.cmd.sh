#! /usr/bin/expect -f
set host_ip 10.180.214.62
set username billroam
set passwd Ailk@462
set timeout -1
spawn ssh $username@$host_ip 
expect {
"yes/no" { send "yes\r"; exp_continue}
"password:" { send "$passwd\r" } 
}
sleep 1 
send "find ./config -type f -name \'*core*\' -exec ls -l --time-style '+%Y%m%d%H%M%S' {} \\;  \r"
sleep 1 
send "exit\r" 
interact
